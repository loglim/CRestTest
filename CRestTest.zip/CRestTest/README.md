# CRestTest
C# / .NET Core version of Rest Api test application 
